let source = 'the-times-of-india';
let apiKey = '70f7c20d246d4708a0cb82ccbd0bc282';

var sel=document.getElementById("category");
var cat=sel.options[sel.selectedIndex].text;


let newsAccordion = document.getElementById('newsAccordion');


const xhr = new XMLHttpRequest();

xhr.open('GET', `https://newsapi.org/v2/everything?sources=${source}&apiKey=${apiKey}`, true);


xhr.onload = function () {
    if (this.status === 200) {
        let json = JSON.parse(this.responseText);
        let articles = json.articles;
        console.log(articles);
        let newsHtml = "";
        articles.forEach(function(element, index) {
    
            let news = `
            <div class="d-flex flex-row bd-highlight mb-3" >
            <div class="col-sm-12 col-md-8 col-lg-3 p-2 card">
                          <div class="p-2">
                            <div class="card-header"  id="heading${index}">
                                <h2 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse${index}"
                                    aria-expanded="false" aria-controls="collapse${index}">
                                   <b style="color:black;font-family: 'Rye', cursive">Current News ${index+1}:</b>
                                
                                   <div class="tit" style="color:red; ">
                                   ${element["title"]}
                                   </div>
                                </button>
                                </h2>
                            </div>

                            <div id="collapse${index}" class="collapse" aria-labelledby="heading${index}" data-parent="#newsAccordion">
                                <div class="card-body"> ${element["content"]}. <a href="${element['url']}" target="_blank" >Read more here</a>  </div>
                            </div>
                            </div>
                        </div>
                        </div>`;
            newsHtml += news;
        });
        newsAccordion.innerHTML = newsHtml;
    }
    else {
        console.log("Some error occured")
    }
}

xhr.send();


